export const environment ={
  production: true,
   firebase : {
    apiKey: "AIzaSyCDZlytqwTnDraoa3faI5AcKBQT0mlbq6c",
    authDomain: "daverxr.firebaseapp.com",
    databaseURL: "https://daverxr.firebaseio.com",
    projectId: "daverxr",
    storageBucket: "daverxr.appspot.com",
    messagingSenderId: "469545251788",
    appId: "1:469545251788:web:ef8f977dac7e09e6182369"
  }
};