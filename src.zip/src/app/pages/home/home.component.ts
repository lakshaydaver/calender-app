import { Component } from '@angular/core';
import {View,EventSettingsModel} from "@syncfusion/ej2-angular-schedule";
//import { AuthService } from './services/auth.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  

    title = 'calender-app';
  
    public setDate: Date =new Date(2020,6,29);
  
  
  public setView:View="Week";
  
  
  public event:EventSettingsModel={
    dataSource:[{
      Subject:"Testing",
      StartTime: new Date(2020,6,30,10,0),
      EndTime: new Date(2020,6,30,11,0),
    }]
  
  
  
  }
  }
