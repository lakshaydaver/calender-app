import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { environment } from './../environments/environment';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFireModule } from '@angular/fire';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

//import { HeaderComponent } from './layout/header/header.component';
import { ScheduleModule, RecurrenceEditorModule ,


WorkWeekService,WeekService,DayService,MonthService,MonthAgendaService



} from '@syncfusion/ej2-angular-schedule';
import { FormsModule } from '@angular/forms';
import { PagenotfoundComponent } from './pages/pagenotfound/pagenotfound.component';
import { SigninComponent } from './pages/signin/signin.component';
import { SignupComponent } from './pages/signup/signup.component';
import { HeaderComponent } from './layout/header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { HomeComponent } from './pages/home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    
    PagenotfoundComponent,
    SigninComponent,
    SignupComponent,
    HeaderComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,AngularFireAuthModule,
    HttpClientModule,
    ScheduleModule, RecurrenceEditorModule,
    AngularFireModule.initializeApp(environment.firebase),BrowserAnimationsModule,
    ToastrModule.forRoot()



  ],
  providers: [WorkWeekService,WeekService,DayService,MonthService,MonthAgendaService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
